import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix

# a.) Iris Data Set and Sklearn

# Pull in data from the source
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'Class']

# Extract into a Pandas DataFrame
dataset = pd.read_csv(url, names=names)

# Get the Attributes and Class Membership
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, 4].values

# Split ino train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Standardize features by removing the mean and scaling to unit variance
# z = (x - u) / s
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

# Instantiate the KNN Classifier
classifier = KNeighborsClassifier(n_neighbors=5)
# Train the KNN Classifier on the training data
classifier.fit(X_train, y_train)

# Use the Trained Classifier to Make Predictions on the Test Data
y_pred = classifier.predict(X_test)

# Evaluate the Models Performance
conf_matrix = confusion_matrix(y_test, y_pred)
class_report = classification_report(y_test, y_pred)

# Display the results
print('Confusion Matrix:')
print(conf_matrix)
print('\nClassification Report:')
print(class_report)

# b.) 10-Fold Cross Validation
from sklearn.model_selection import cross_val_score

# i. Neighbors list 1-100 odd numbers only
neighbors = [i for i in range(1, 100, 2)]
# Alternatively with filter
neighbors = list(filter(lambda a: a%2 > 0, [i for i in range(1, 100)]))

# ii. Train and Evaluate with 10-fold cross validation varying the number neighboors

# Create a list to store k-varying errors in
errorList = []
for k in neighbors:
    # Instantiate the KNN Classifier
    knn = KNeighborsClassifier(n_neighbors=k)
    # Run 10-Fold Cross Validation on the KNN Classifier
    evaluation10 = cross_val_score(knn, X, y, scoring='accuracy', cv=10)
    avgError = 1.0 - sum(evaluation10)/len(evaluation10)
    errorList.append(avgError)

# iv.Plot Neighbors vs. MSE and find optimal K
plt.plot(neighbors, errorList)
plt.xlabel("neighbors")
plt.ylabel("MSE")
plt.savefig('MSE_vs_neighbors.png')
optimalK = neighbors[errorList.index(min(errorList))]
print(f'Optimal K: {optimalK}')