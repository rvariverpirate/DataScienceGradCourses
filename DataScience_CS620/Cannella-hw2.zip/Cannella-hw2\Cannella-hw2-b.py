"""
CS 620
HW2-b
@author: Joseph Cannella
"""
# %%
from matplotlib import pyplot as plt
from sklearn import linear_model, datasets
import pandas as pd
import glob
import gc
import os
import numpy as np

#part I
path = r'yob-names' # use your path
all_files = glob.glob(path + "/*.txt")

# Setup:

# Retrieve the file if it already exists
if(os.path.exists('yob-names.csv')):
    namesDF = pd.read_csv('yob-names.csv')

# Otherwise generate it from the collection of other files
else:
    # Setup empty dataframe
    namesDF = pd.DataFrame(columns=['year', 'name', 'gender', 'count'])
    # Parse each file individually
    for f_name in all_files:
        year = int(f_name.split('yob-names\yob')[1].split('.')[0])
        tmp = pd.read_csv(f_name)
        tmp.columns = ['name', 'gender', 'count']
        tmp['year'] = np.full(len(tmp), year)
        namesDF = namesDF.append(tmp)

    # Save the results to another .csv
    namesDF.to_csv('yob-names.csv')

# Part II
# a)	What is the most popular boys name in year 1980?
year_filter = namesDF["year"] == 1980
gender_filter = namesDF["gender"] == 'M'
boy_names1980 = namesDF[year_filter & gender_filter]
most_pop_filter = boy_names1980['count'] == boy_names1980['count'].max()
most_pop_boy_name = boy_names1980[most_pop_filter].name
print('most popular boys name in 1980: ', most_pop_boy_name, '\n')

# b)	How many girls were born between 1990 and 2000?
year_filter_min = namesDF['year'] >= 1990
year_filter_max =  namesDF['year'] <= 2000
gender_filter = namesDF['gender'] == 'F'
num_girls = namesDF[year_filter_min & year_filter_max & gender_filter]['count'].count()
print('number of girls born between 1990 and 2000: ', num_girls, '\n')

#c)	How many female Benjamin’s are alive today (year 2020)? 
year_filter_min = namesDF['year'] >= 1950
gender_filter = namesDF['gender'] == 'F'
name_filter = namesDF['name'] == 'Benjamin'
femaleBenDF = namesDF[year_filter_min & gender_filter & name_filter]
femaleBenDF = femaleBenDF.drop(['gender', 'name'], axis=1)

# Fill in missing years (2019-2020)
X = femaleBenDF['year'].values.reshape(-1, 1)
Y = femaleBenDF['count'].values.reshape(-1, 1)
count_pred = linear_model.LinearRegression().fit(X, Y)
future = np.arange(2019, 2021)
predicted_count = count_pred.predict(future.reshape(-1, 1)).reshape(1,-1)[0]
predDF = pd.DataFrame(zip(future, predicted_count), columns=['year', 'count'])
femaleBenDF = femaleBenDF.append(predDF)

# Pull in and format Life Expectancy Data
lifeExpectancy = pd.read_csv("cdc-life-expectancy.csv")
lifeExpectancy = lifeExpectancy.drop(['M'], axis=1)
year_filter = lifeExpectancy['year'] >= 1950
lifeExpectancy = lifeExpectancy[year_filter]
now = 2020
X = lifeExpectancy['year'].values.reshape(-1,1)
Y = lifeExpectancy['F'].values.reshape(-1,1)

# Test a Linear Model
lin_reg = linear_model.LinearRegression().fit(X, Y)
Y_lin_pred = lin_reg.predict(X)

# Make Presictions from 2013 to 2020
future = np.arange(2013, 2021)
predictedExp = lin_reg.predict(future.reshape(-1, 1)).reshape(1,-1)[0]
predDF = pd.DataFrame(zip(future, predictedExp), columns=['year', 'F'])

# Add the predicted data back in
lifeExpectancy = lifeExpectancy.append(predDF)

# Merge the two DataFrames on Year
mergedDF = lifeExpectancy.merge(femaleBenDF, on='year')

# Replace year with years ago
mergedDF['year'] = mergedDF['year'].apply(lambda y: 2020-y)

# Because standard deviation is not known
# Assume everyone dies at their average life expectancy
stillAliveFilter = mergedDF['F'] > mergedDF['year']

# Apply the filter
stillAliveDF = mergedDF[stillAliveFilter]

# Count the Benjamins
aliveToday = stillAliveDF['F'].sum()

print('Living female Benjamins: ', aliveToday)

# %%
