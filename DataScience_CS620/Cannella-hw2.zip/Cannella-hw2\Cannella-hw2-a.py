"""
CS 620
HW2-a
@author: Joseph S Cannella
"""


"""Given two list of numbers that are already sorted, 
 return a single merged list in sorted order.
"""
import numpy as np

def merge(sortedListA, sortedListB):
    
    counts = min(len(sortedListA), len(sortedListB))
    aIdx = bIdx = 0
    sortedList = []

    # Continually append the lesser of the values
    while(aIdx < counts and bIdx < counts):
        if(sortedListA[aIdx] <= sortedListB[bIdx]):
            sortedList.append(sortedListA[aIdx])
            aIdx += 1
        else:
            sortedList.append(sortedListB[bIdx])
            bIdx += 1
    
    # Add any remaining vlaues form A
    while(aIdx < len(sortedListA)):
        sortedList.append(sortedListA[aIdx])
        aIdx += 1

    # Add any remaining values from B
    while(bIdx < len(sortedListB)):
        sortedList.append(sortedListB[bIdx])
        bIdx += 1

    return sortedList

"""Given a list of numbers in random order, return the summary statistics 
that includes the max, min, mean, population standard deviation, median,
75 percentile, and 25 percentile.
"""    
def summaryStatistics(listOfNums):
    #Complete this part. 
    # You can decide to return the following statistics either in a sequence 
    # type (i.e., list, tuple), or a key-value pair (i.e., dictionary)
    
    arrayOfNums = np.array(listOfNums)

    maxVal = arrayOfNums.max()
    minVal = arrayOfNums.min()
    meanVal = np.mean(arrayOfNums)
    stdev = np.std(arrayOfNums)
    median = np.median(arrayOfNums)
    perc75 = np.percentile(arrayOfNums, 75)
    perc25 = np.percentile(arrayOfNums, 25)


    
    return {'max': maxVal, 
            'min': minVal, 
            'mean': meanVal, 
            'stdev': stdev,
            'median': median,
            'perc75': perc75,
            'perc25': perc25}

"""Given a list of real numbers in any range, scale them to be 
between 0 and 1 (inclusive). For each number x in the list, the new number 
is computed with the formula ((x - min)/(max - min)) where max is the 
maximum value of the original list and min is the minimum value of the list. 
"""	
def minMax(listOfNums): 
    arrayOfNums = np.array(listOfNums)
    min = arrayOfNums.min()
    max = arrayOfNums.max()
    diff = max - min
    normalizer = lambda val:  (val - min)/diff
    vfunc = np.vectorize(normalizer) 
    newList = vfunc(arrayOfNums)
    return newList